export interface AuthData {
  full_name : string| null;
  email: string;
  password: string;
  role : string | null;
}
